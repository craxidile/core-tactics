﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entitas;
using UnityEngine;

namespace Taiga.Tools
{
  public class MapTools
  {
    private static readonly Tuple<int, int>[] AdjacentDiffs =
      {Tuple.Create(0, -1), Tuple.Create(-1, 0), Tuple.Create(1, 0), Tuple.Create(0, 1)};
    
    private static readonly Tuple<int, int>[] PlayerRotationDiffs =
    {
      Tuple.Create(0, -1), Tuple.Create(0, -2), Tuple.Create(0, -3),
      Tuple.Create(-1, 0), Tuple.Create(-2, 0), Tuple.Create(-3, 0),
      Tuple.Create(1, 0), Tuple.Create(2, 0), Tuple.Create(3, 0),
      Tuple.Create(0, 1), Tuple.Create(0, 2), Tuple.Create(0, 3)
    };

    public static Tuple<int, int>[] FindPlayerRotationCells(int[,] map, Tuple<int, int> origin)
    {
      var possibleRotationCellList = new List<Tuple<int, int>>();
      foreach (var adjacentDiff in PlayerRotationDiffs)
      {
        var (column, row) = origin;
        var (columnDiff, rowDiff) = adjacentDiff;
        var adjacentCell = Tuple.Create(column + columnDiff, row + rowDiff);
        var (adjacentColumn, adjacentRow) = adjacentCell;
        if (adjacentColumn < map.GetLength(0) && adjacentRow < map.GetLength(1))
        {
          possibleRotationCellList.Add(adjacentCell);
        }
      }

      return possibleRotationCellList.ToArray();
    }

    public static Tuple<int, int>[] FindAdjacentCells(int[,] map, Tuple<int, int> origin)
    {
      var possibleAttackCellList = new List<Tuple<int, int>>();
      foreach (var adjacentDiff in AdjacentDiffs)
      {
        var (column, row) = origin;
        var (columnDiff, rowDiff) = adjacentDiff;
        var adjacentCell = Tuple.Create(column + columnDiff, row + rowDiff);
        var (adjacentColumn, adjacentRow) = adjacentCell;
        if (adjacentColumn < map.GetLength(0) && adjacentRow < map.GetLength(1))
        {
          possibleAttackCellList.Add(adjacentCell);
        }
      }

      return possibleAttackCellList.ToArray();
    }

    public static Tuple<int, int>[] FindPossibleAttackCells(int[,] map, Tuple<int, int> origin)
    {
      var possibleAttackCellList = new List<Tuple<int, int>>();
      foreach (var adjacentDiff in AdjacentDiffs)
      {
        var (column, row) = origin;
        var (columnDiff, rowDiff) = adjacentDiff;
        var adjacentCell = Tuple.Create(column + columnDiff, row + rowDiff);
        var (adjacentColumn, adjacentRow) = adjacentCell;
        if (adjacentColumn > 0 && adjacentRow > 0 && adjacentColumn < map.GetLength(0) &&
            adjacentRow < map.GetLength(1) && map[adjacentColumn, adjacentRow] < 0)
        {
          possibleAttackCellList.Add(adjacentCell);
        }
      }

      return possibleAttackCellList.ToArray();
    }

    public static Tuple<int, int>[] FindPath(Tuple<int, int>[] possibleCells, Tuple<int, int> origin,
      Tuple<int, int> destination, List<List<Tuple<int, int>>> paths = null, int count = 10)
    {
      if (count == 0)
      {
        return null;
      }

      if (paths == null)
      {
        paths = new List<List<Tuple<int, int>>>() {new List<Tuple<int, int>>() {origin}};
      }

      UnityEngine.Debug.Log(">>total_paths<< " + paths.Count);

      List<Tuple<int, int>> foundPath = null;
      var nextPaths = new List<List<Tuple<int, int>>>();
      foreach (var path in paths)
      {
        var cell = path.Last();
        foreach (var adjacentDiff in AdjacentDiffs)
        {
          var (columnDiff, rowDiff) = adjacentDiff;
          var (column, row) = cell;
          var nextCell = Tuple.Create(column + columnDiff, row + rowDiff);
          if (path.Contains(nextCell) || !possibleCells.Contains(nextCell))
          {
            continue;
          }

          var nextPath = new List<Tuple<int, int>>(path);
          nextPath.Add(nextCell);
          if (!nextCell.Equals(destination))
          {
            nextPaths.Add(nextPath);
          }
          else
          {
            foundPath = nextPath;
            break;
          }
        }

        if (foundPath != null)
        {
          break;
        }
      }

      if (foundPath == null)
      {
        return FindPath(possibleCells, origin, destination, nextPaths, count - 1);
      }

      return foundPath.ToArray();
    }

    public static Tuple<int, int>[] PopulateCells(int[,] map, int playerColumn,
      int playerRow, int move, Dictionary<Tuple<int, int>, Tuple<int, int>[]> pathDict = null)
    {
      if (move == 0)
      {
        return null;
      }

      if (pathDict == null)
      {
        pathDict = new Dictionary<Tuple<int, int>, Tuple<int, int>[]>();
        pathDict.Add(Tuple.Create(playerColumn, playerRow), new Tuple<int, int>[0]);
      }

      foreach (var adjacentDiff in AdjacentDiffs)
      {
        var (columnDiff, rowDiff) = adjacentDiff;
        var nextColumn = playerColumn + columnDiff;
        var nextRow = playerRow + rowDiff;
        // UnityEngine.Debug.Log($">>adj_cells<< ({nextColumn}, {nextRow})");
        if (nextColumn < 0 || nextColumn >= map.GetLength(0) || nextRow < 0 || nextRow >= map.GetLength(1) ||
            map[nextColumn, nextRow] != 0)
        {
          continue;
        }

        var prevKey = Tuple.Create(playerColumn, playerRow);
        var key = Tuple.Create(nextColumn, nextRow);
        if (!pathDict.ContainsKey(prevKey) && !pathDict.ContainsKey(key))
        {
          var path = new[] {Tuple.Create(nextColumn, nextRow)};
          pathDict.Add(key, path);
        }
        else if (pathDict.ContainsKey(prevKey))
        {
          var prevPath = pathDict[prevKey];
          var path = new Tuple<int, int>[prevPath.Length + 1];
          Array.Copy(prevPath, path, prevPath.Length);
          path[path.Length - 1] = Tuple.Create(nextColumn, nextRow);
          if (!pathDict.ContainsKey(key))
          {
            pathDict.Add(key, path);
          }
          else
          {
            var sameDestPath = pathDict[key];
            if (path.Length < sameDestPath.Length)
            {
              pathDict[key] = path;
            }
          }
        }
      }

      foreach (var adjacentDiff in AdjacentDiffs)
      {
        var (columnDiff, rowDiff) = adjacentDiff;
        var nextColumn = playerColumn + columnDiff;
        var nextRow = playerRow + rowDiff;
        if (nextColumn < 0 || nextColumn >= map.GetLength(0) || nextRow < 0 || nextRow >= map.GetLength(1) ||
            map[nextColumn, nextRow] != 0)
        {
          continue;
        }

        PopulateCells(map, nextColumn, nextRow, move - 1, pathDict);
      }

      return pathDict.Keys.ToArray();
    }

    public static int[,] Generate(int columnCount, int rowCount, GameEntity[] gameEntities, int playerIndex)
    {
      var playerEntity = gameEntities.AsEnumerable()
        .Where(e => e.playerOld.index == playerIndex)
        .FirstOrDefault();
      if (playerEntity == null)
      {
        return null;
      }

      var (playerColumn, playerRow) = playerEntity.position;
      var map = new int[columnCount + 1, rowCount + 1];
      for (var column = 0; column < map.GetLength(0); column++)
      {
        for (var row = 0; row < map.GetLength(1); row++)
        {
          map[column, row] = 0;
        }
      }

      foreach (var entity in gameEntities)
      {
        var position = entity.position;
        var (column, row) = position;
        var isOpponent = entity.playerOld.isOpponent;
        map[column, row] = isOpponent ? -2 : 2;
      }

      map[playerColumn, playerRow] = 1;
      return map;
    }

    public static string MapToString(int[,] map)
    {
      var mapTextBuilder = new StringBuilder();
      for (var row = 0; row < map.GetLength(1); row++)
      {
        var rowTextBuilder = new StringBuilder();
        for (var column = 0; column < map.GetLength(0); column++)
        {
          rowTextBuilder.Append($"{(map[column, row] + "").PadLeft(2, ' ')} ");
        }

        rowTextBuilder.Remove(rowTextBuilder.Length - 1, 1);
        mapTextBuilder.Append($"{rowTextBuilder}\n");
      }

      if (mapTextBuilder.Length > 0)
      {
        mapTextBuilder.Remove(mapTextBuilder.Length - 1, 1);
      }

      return mapTextBuilder.ToString();
    }

    public static void Debug(int[,] map)
    {
      UnityEngine.Debug.Log(MapToString(map));
    }
  }
}