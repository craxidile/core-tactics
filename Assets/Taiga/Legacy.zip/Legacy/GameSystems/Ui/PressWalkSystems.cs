﻿using System.Collections.Generic;
using System.Linq;
using Entitas;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Ui
{
  public class PressWalkSystems : ReactiveSystem<InputEntity>
  {
    private GameContext _gameContext;

    public PressWalkSystems(Contexts contexts) : base(contexts.input)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<InputEntity> GetTrigger(IContext<InputEntity> context)
    {
      return context.CreateCollector(InputMatcher.AllOf(InputMatcher.MouseCursor, InputMatcher.MousePress));
    }

    protected override bool Filter(InputEntity entity)
    {
      return entity.hasMousePress;
    }

    protected override void Execute(List<InputEntity> entities)
    {
      var entity = entities.FirstOrDefault();
      if (entity == null)
      {
        return;
      }

      var menuPresenter = GameObject.FindObjectOfType<MenuPresenter>();
      var gameObject = entity.mouseOver.gameObject;

      var moveActive = gameObject == menuPresenter.inactiveMoveMenu ||
                       gameObject == menuPresenter.activeMoveMenu.transform.GetChild(0).gameObject;
      if (!moveActive)
      {
        return;
      }

      _gameContext.ReplaceCurrentState(SceneStateType.Move);
      entity.RemoveMousePress();
    }
  }
}