﻿using System.Collections.Generic;
using System.Linq;
using Entitas;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Ui
{
  public class WalkMenuInputSystems : ReactiveSystem<InputEntity>
  {
    private GameContext _gameContext;

    public WalkMenuInputSystems(Contexts contexts) : base(contexts.input)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<InputEntity> GetTrigger(IContext<InputEntity> context)
    {
      return context.CreateCollector(InputMatcher.AllOf(InputMatcher.MouseCursor, InputMatcher.MouseOver));
    }

    protected override bool Filter(InputEntity entity)
    {
      return entity.hasMouseOver;
    }

    protected override void Execute(List<InputEntity> entities)
    {
      var entity = entities.FirstOrDefault();
      if (entity == null)
      {
        return;
      }

      var menuPresenter = GameObject.FindObjectOfType<MenuPresenter>();
      var gameObject = entity.mouseOver.gameObject;
      Debug.Log(">>game_object<< " + gameObject);

      var confirmationActive = gameObject == menuPresenter.inactiveConfirmWalkingMenu ||
                               gameObject == menuPresenter.activeConfirmWalkingMenu;
      var cancellationActive = gameObject == menuPresenter.inactiveCancelWalkingMenu ||
                               gameObject == menuPresenter.activeCancelWalkingMenu;

      menuPresenter.inactiveConfirmWalkingMenu.SetActive(!confirmationActive);
      menuPresenter.activeConfirmWalkingMenu.SetActive(confirmationActive);
      menuPresenter.inactiveCancelWalkingMenu.SetActive(!cancellationActive);
      menuPresenter.activeCancelWalkingMenu.SetActive(cancellationActive);
    }
  }
}