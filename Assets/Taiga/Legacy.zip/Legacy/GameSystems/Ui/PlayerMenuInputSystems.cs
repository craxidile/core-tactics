﻿using System;
using System.Collections.Generic;
using System.Linq;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using Taiga.Tools;
using UnityEngine;

namespace Taiga.GameSystem.Ui
{
  public class PlayerMenuInputSystems : ReactiveSystem<InputEntity>
  {
    private Contexts _contexts;
    private GameContext _gameContext;

    public PlayerMenuInputSystems(Contexts contexts) : base(contexts.input)
    {
      _contexts = contexts;
      _gameContext = contexts.game;
    }

    protected override ICollector<InputEntity> GetTrigger(IContext<InputEntity> context)
    {
      return context.CreateCollector(InputMatcher.AllOf(InputMatcher.MouseCursor, InputMatcher.MouseOver));
    }

    protected override bool Filter(InputEntity entity)
    {
      return entity.hasMouseOver;
    }

    protected override void Execute(List<InputEntity> entities)
    {
      var entity = entities.FirstOrDefault();
      if (entity == null)
      {
        return;
      }

      var menuPresenter = GameObject.FindObjectOfType<MenuPresenter>();
      var gameObject = entity.mouseOver.gameObject;
      Debug.Log(">>game_object<< " + gameObject);

      var moveActive = gameObject == menuPresenter.inactiveMoveMenu ||
                       gameObject == menuPresenter.activeMoveMenu.transform.GetChild(0).gameObject;
      var attackActive = gameObject == menuPresenter.inactiveAttackMenu ||
                         gameObject == menuPresenter.activeAttackMenu.transform.GetChild(0).gameObject;
      // var specialActive = gameObject == menuPresenter.inactiveSpecialMenu ||
      //                  gameObject == menuPresenter.activeSpecialMenu.transform.GetChild(0).gameObject;
      var waitActive = gameObject == menuPresenter.inactiveWaitMenu ||
                       gameObject == menuPresenter.activeWaitMenu.transform.GetChild(0).gameObject;


      var previousState = _gameContext.previousState.type;

      if (previousState != SceneStateType.Move)
      {
        menuPresenter.activeMoveMenu.transform.GetChild(0).gameObject.SetActive(true);
        menuPresenter.inactiveMoveMenu.SetActive(!moveActive);
        menuPresenter.activeMoveMenu.SetActive(moveActive);
      }
      else
      {
        menuPresenter.inactiveMoveMenu.SetActive(false);
        menuPresenter.activeMoveMenu.SetActive(true);
        menuPresenter.activeMoveMenu.transform.GetChild(0).gameObject.SetActive(false);
      }

      // Determine whether the current player is able to attack
      var possibleAdjacentCells = _contexts.FindAttackableCells();
      var attackPossible = possibleAdjacentCells.Length > 0;

      menuPresenter.inactiveAttackMenu.SetActive(attackPossible && !attackActive);
      menuPresenter.activeAttackMenu.SetActive(attackPossible && attackActive);
      
      // End determining whether the current player is able to attack
      
      // menuPresenter.inactiveSpecialMenu.SetActive(!specialActive);
      // menuPresenter.activeSpecialMenu.SetActive(specialActive);
      menuPresenter.inactiveWaitMenu.SetActive(!waitActive);
      menuPresenter.activeWaitMenu.SetActive(waitActive);
    }
  }
}