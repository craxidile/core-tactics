﻿using System.Collections.Generic;
using System.Linq;
using Entitas;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Ui
{
  public class PressCancelWalkingSystems : ReactiveSystem<InputEntity>
  {
    private GameContext _gameContext;

    public PressCancelWalkingSystems(Contexts contexts) : base(contexts.input)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<InputEntity> GetTrigger(IContext<InputEntity> context)
    {
      return context.CreateCollector(InputMatcher.AllOf(InputMatcher.MouseCursor, InputMatcher.MousePress));
    }

    protected override bool Filter(InputEntity entity)
    {
      return entity.hasMousePress;
    }

    protected override void Execute(List<InputEntity> entities)
    {
      var entity = entities.FirstOrDefault();
      if (entity == null)
      {
        return;
      }

      var menuPresenter = GameObject.FindObjectOfType<MenuPresenter>();
      var gameObject = entity.mouseOver.gameObject;

      var cancelWalkingActive = gameObject == menuPresenter.inactiveCancelWalkingMenu ||
                                gameObject == menuPresenter.activeCancelWalkingMenu;
      if (!cancelWalkingActive)
      {
        return;
      }

      _gameContext.ReplaceCurrentState(SceneStateType.Move);
      entity.RemoveMousePress();
    }
  }
}