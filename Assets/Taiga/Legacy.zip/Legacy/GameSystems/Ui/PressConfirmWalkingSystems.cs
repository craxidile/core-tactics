﻿using System.Collections.Generic;
using System.Linq;
using Entitas;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Ui
{
  public class PressConfirmWalkingSystems : ReactiveSystem<InputEntity>
  {
    private GameContext _gameContext;

    public PressConfirmWalkingSystems(Contexts contexts) : base(contexts.input)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<InputEntity> GetTrigger(IContext<InputEntity> context)
    {
      return context.CreateCollector(InputMatcher.AllOf(InputMatcher.MouseCursor, InputMatcher.MousePress));
    }

    protected override bool Filter(InputEntity entity)
    {
      return entity.hasMousePress;
    }

    protected override void Execute(List<InputEntity> entities)
    {
      var entity = entities.FirstOrDefault();
      if (entity == null)
      {
        return;
      }

      var menuPresenter = GameObject.FindObjectOfType<MenuPresenter>();
      var gameObject = entity.mouseOver.gameObject;

      var confirmWalkingActive = gameObject == menuPresenter.inactiveConfirmWalkingMenu ||
                                 gameObject == menuPresenter.activeConfirmWalkingMenu;
      if (!confirmWalkingActive)
      {
        return;
      }

      _gameContext.ReplacePreviousState(SceneStateType.Move);
      _gameContext.ReplaceCurrentState(SceneStateType.PlayerMenu);
      
      entity.RemoveMousePress();
    }
  }
}