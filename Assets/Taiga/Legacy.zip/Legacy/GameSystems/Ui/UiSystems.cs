﻿namespace Taiga.GameSystem.Ui
{
  public class UiSystems : Feature
  {
    public UiSystems(Contexts contexts) : base("UI Systems")
    {
      Add(new PlayerMenuVisibilitySystems(contexts));
      Add(new PlayerMenuInputSystems(contexts));
      Add(new WalkMenuInputSystems(contexts));
      Add(new WalkMenuVisibilitySystems(contexts));
      Add(new PressWalkSystems(contexts));
      Add(new PressWaitSystems(contexts));
      Add(new PressConfirmWalkingSystems(contexts));
      Add(new PressCancelWalkingSystems(contexts));
      Add(new PressAttackSystems(contexts));
    }
  }
}