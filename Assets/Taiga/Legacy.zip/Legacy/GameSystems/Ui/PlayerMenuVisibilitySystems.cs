﻿using System.Collections.Generic;
using System.Linq;
using Entitas;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Ui
{
  public class PlayerMenuVisibilitySystems : ReactiveSystem<GameEntity>
  {
    private GameContext _gameContext;

    public PlayerMenuVisibilitySystems(Contexts contexts) : base(contexts.game)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.CurrentState));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasCurrentState;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      var menuPresenter = GameObject.FindObjectOfType<MenuPresenter>();
      var playerMenu = menuPresenter.playerMenu;
      playerMenu.SetActive(_gameContext.currentState.type == SceneStateType.PlayerMenu);
    }
  }
}