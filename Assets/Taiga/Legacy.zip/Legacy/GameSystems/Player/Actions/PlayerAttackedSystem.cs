﻿using System.Collections.Generic;
using System.Linq;
using DG.Tweening;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using UnityEngine;

namespace Taiga.GameSystem.Player.Actions
{
  public class PlayerAttackedSystem : ReactiveSystem<GameEntity>
  {
    private GameContext _gameContext;

    public PlayerAttackedSystem(Contexts contexts) : base(contexts.game)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.Player, GameMatcher.PlayerState));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasPlayerState;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      var playerEntity = entities.FirstOrDefault();
      if (playerEntity == null)
      {
        return;
      }

      if (playerEntity.playerState.type != PlayerStateType.Attacked)
      {
        return;
      }

      playerEntity.RemovePlayerState();

      var gameObject = playerEntity.view.gameObject;
      var parentObject = gameObject.transform.parent.gameObject;
      var animator = gameObject.GetComponent<Animator>();

      var sequence = DOTween.Sequence();
      sequence.AppendInterval(0.55f);
      sequence.AppendCallback(() => { animator.SetInteger($"State", 4); });
      sequence.Append(gameObject.transform.DOShakePosition(0.37f, new Vector3(0.08f, 0, 0.08f), 28, 20, false, false));
      sequence.AppendCallback(() => { animator.SetInteger($"State", 1); });
    }
  }
}