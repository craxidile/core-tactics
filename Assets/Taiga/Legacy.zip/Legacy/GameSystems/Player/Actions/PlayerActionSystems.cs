﻿namespace Taiga.GameSystem.Player.Actions
{
  public class PlayerActionSystems : Feature
  {

    public PlayerActionSystems(Contexts contexts) : base("Player Action")
    {
      Add(new PlayerAttackingSystem(contexts));
      Add(new PlayerAttackedSystem(contexts));
    }
    
  }
}