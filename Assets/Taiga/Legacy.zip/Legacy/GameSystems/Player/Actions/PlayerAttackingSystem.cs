﻿using System.Collections.Generic;
using System.Linq;
using DG.Tweening;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Player.Actions
{
  public class PlayerAttackingSystem : ReactiveSystem<GameEntity>
  {
    private GameContext _gameContext;

    public PlayerAttackingSystem(Contexts contexts) : base(contexts.game)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.Player, GameMatcher.PlayerState));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasPlayerState;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      var playerEntity = entities.FirstOrDefault();
      if (playerEntity == null)
      {
        return;
      }

      if (playerEntity.playerState.type != PlayerStateType.Attacking)
      {
        return;
      }

      playerEntity.RemovePlayerState();
      
      Debug.Log(">>attacking<<");

      var gameObject = playerEntity.view.gameObject;
      var parentObject = gameObject.transform.parent.gameObject;
      var animator = gameObject.GetComponent<Animator>();
      animator.SetInteger($"State", 3);

      var idlePosition = parentObject.transform.position.Clone();
      var attackingPosition = idlePosition.Clone();
      attackingPosition.z += 0.3f;
      // parentObject.transform.position = attackingPosition;

      var audioSequence = DOTween.Sequence();
      audioSequence.AppendInterval(0.43f);
      audioSequence.AppendCallback(() =>
      {
        var soundPresenter = GameObject.FindObjectOfType<SoundPresenter>();
        soundPresenter.Play(SoundEffectType.Punch);
      });
      
      var sequence = DOTween.Sequence();
      sequence.Append(parentObject.transform.DOMove(attackingPosition, 0.17f));
      sequence.AppendInterval(0.6f);
      sequence.AppendCallback(() => { animator.speed = 0; });
      sequence.AppendInterval(0.25f);
      sequence.AppendCallback(() => { animator.speed = 1; });
      sequence.AppendInterval(0.4f);
      sequence.AppendCallback(() =>
      {
        animator.SetInteger($"State", 1);
        parentObject.transform.position = idlePosition;
      });
    }
  }
}