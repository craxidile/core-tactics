﻿using System.Collections.Generic;
using System.Linq;
using Entitas;
using Entitas.Unity;
using Taiga.Extensions;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Player
{
  public class AddPlayerSystems : ReactiveSystem<GameEntity>
  {
    private GameContext _gameContext;

    public AddPlayerSystems(Contexts contexts) : base(contexts.game)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.View);
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasView && entity.hasPosition && entity.hasPlayer && !entity.isInitialized;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      var decorationPresenter = GameObject.FindObjectOfType<DecorationPresenter>();
      var uiPresenter = GameObject.FindObjectOfType<UiPresenter>();
      var mapPresenter = GameObject.FindObjectOfType<MapPresenter>();

      var playerFloor = mapPresenter.playerFloor;

      var map = mapPresenter.map;
      var (mapColumn, mapRow) = map.transform.position.ToVector2();

      foreach (var entity in entities)
      {
        entity.isInitialized = true;

        var gameObject = new GameObject();
        var position = entity.position;
        var player = entity.playerOld;

        var (column, row) = position;
        var x = -column - mapColumn; // - 0.5f;
        var z = row + mapRow; // + 0.5f;

        gameObject.transform.position = new Vector3(x, 0.75f, z);
        gameObject.transform.localRotation = Quaternion.Euler(0, 0, 0);
        gameObject.transform.SetParent(playerFloor.transform, true);

        var characterObject = entity.view.gameObject;
        characterObject.transform.SetParent(gameObject.transform, false);
        characterObject.transform.localPosition = new Vector3(-0.5f, 0, 0.5f);
        characterObject.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
        entity.ReplaceView(characterObject);

        var rotSouthObject = decorationPresenter.CreateRotationArrowSouth();
        rotSouthObject.transform.SetParent(gameObject.transform, false);
        rotSouthObject.transform.localPosition = new Vector3(-0.5f, 0, 1f);
        rotSouthObject.SetActive(false);

        var rotNorthObject = decorationPresenter.CreateRotationArrowNorth();
        rotNorthObject.transform.SetParent(gameObject.transform);
        rotNorthObject.transform.localPosition = new Vector3(-0.5f, 0, 0);
        rotNorthObject.SetActive(false);
        
        var rotEastObject = decorationPresenter.CreateRotationArrowEast();
        rotEastObject.transform.SetParent(gameObject.transform);
        rotEastObject.transform.localPosition = new Vector3(0, 0, 0.5f);
        rotEastObject.SetActive(false);
        
        var rotWestObject = decorationPresenter.CreateRotationArrowWest();
        rotWestObject.transform.SetParent(gameObject.transform);
        rotWestObject.transform.localPosition = new Vector3(-1f, 0, 0.5f);
        rotWestObject.SetActive(false);

        var shadowObject = decorationPresenter.CreateShadow();
        shadowObject.transform.SetParent(gameObject.transform, false);
        shadowObject.transform.localPosition = new Vector3(-0.5f, 0, 0.5f);

        var arrowObject = decorationPresenter.CreateArrowDown();
        arrowObject.transform.SetParent(gameObject.transform, false);
        arrowObject.transform.localPosition = new Vector3(-0.5f, 0, 0.5f);
        entity.AddArrow(arrowObject);

        var bannerObject = entity.banner.gameObject;
        bannerObject.transform.SetParent(uiPresenter.canvas.transform, false);
        bannerObject.transform.localScale = new Vector3(1f, 1f, 1f);
        bannerObject.SetActive(false);
        
        entity.AddRotationArrow(rotNorthObject, rotSouthObject, rotEastObject, rotWestObject);
        entity.ReplaceBanner(bannerObject);

        var animator = characterObject.GetComponent<Animator>();
        animator.SetInteger($"State", 1);
        animator.SetBool($"Front", !player.isOpponent);


        // var cameras = GameObject.FindObjectsOfType<Camera>();
        // var arrowCamera = cameras.Where(c => c != Camera.main).FirstOrDefault().gameObject;
        // arrowCamera.SetActive(false);

        gameObject.Link(entity);
      }
    }
  }
}