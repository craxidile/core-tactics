﻿using System;
using System.Collections.Generic;
using System.Linq;
using DG.Tweening;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Player
{
  public class PlayerAttackSystems : ReactiveSystem<GameEntity>
  {
    private GameContext _gameContext;

    public PlayerAttackSystems(Contexts contexts) : base(contexts.game)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.AttackPosition));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasAttackPosition && _gameContext.currentState.type == SceneStateType.Attack;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      Debug.Log(">>player_attack<<");
      var camera = _gameContext.GetGroup(GameMatcher.AllOf(GameMatcher.GameCamera)).GetSingleEntity();
      DOTween.To(
        () => camera.gameCamera.gameObject.orthographicSize,
        x => { camera.gameCamera.gameObject.orthographicSize = x; },
        1.7f,
        .2f
      ).SetEase(Ease.InCubic);

      var mainLight = GameObject.FindObjectOfType<LightPresenter>().mainLight;
      DOTween.To(
        () => mainLight.intensity,
        x => { mainLight.intensity = x; },
        0.1f,
        .2f
      ).SetEase(Ease.InCubic);

      var sequence = DOTween.Sequence();
      sequence.AppendInterval(1.4f);
      sequence.AppendCallback(() =>
      {
        _gameContext.RemoveAttackPosition();
        _gameContext.ReplaceCurrentState(SceneStateType.AttackDone);
      });

      var gameEntity = _gameContext.GetGroup(GameMatcher.AllOf(GameMatcher.CurrentPlayer)).GetSingleEntity();
      var playerEntities = _gameContext.GetGroup(GameMatcher.AllOf(GameMatcher.Player));

      // Debug.Log(">>game<< " + _gameContext.GetGroup(GameMatcher.AllOf(GameMatcher.CurrentPlayer)).count);
      foreach (var playerEntity in playerEntities)
      {
        var gameObject = playerEntity.view.gameObject;
        // var animator = gameObject.GetComponent<Animator>();
        var renderer = gameObject.GetComponent<SpriteRenderer>();
        if (playerEntity.playerOld.index == gameEntity.currentPlayer.index)
        {
          Debug.Log(">>trigger_attacking<<");
          playerEntity.AddPlayerState(PlayerStateType.Attacking);
          // animator.SetInteger($"State", 3);
        }
        else if (playerEntity.playerOld.index == -gameEntity.currentPlayer.index)
        {
          // TODO: Delay attacked frame and shake
          // TODO: End shaking before the attack ends
          playerEntity.AddPlayerState(PlayerStateType.Attacked);
          // animator.SetInteger($"State", 4);
        }
        else
        {
          renderer.color = Color.gray;
        }
      }
    }
  }
}