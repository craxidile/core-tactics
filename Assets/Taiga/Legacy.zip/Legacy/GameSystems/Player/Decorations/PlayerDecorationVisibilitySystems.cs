﻿using System.Collections.Generic;
using Entitas;
using Taiga.Extensions;

namespace Taiga.GameSystem.Player.Decorations
{
  public class PlayerDecorationVisibilitySystems : ReactiveSystem<GameEntity>
  {
    private Contexts _contexts;

    public PlayerDecorationVisibilitySystems(Contexts contexts) : base(contexts.game)
    {
      _contexts = contexts;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.CurrentPlayer));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasCurrentPlayer;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      var currentPlayerEntity = _contexts.CurrentPlayer();
      var playerEntities = _contexts.Players();
      foreach (var playerEntity in playerEntities)
      {
        var active = playerEntity == currentPlayerEntity;
        playerEntity.banner.gameObject.SetActive(active);
        playerEntity.arrow.gameObject.SetActive(active);
      }
    }
  }
}