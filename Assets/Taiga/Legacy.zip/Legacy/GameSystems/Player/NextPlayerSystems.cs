﻿using System;
using System.Collections.Generic;
using System.Linq;
using DG.Tweening;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Player
{
  public class NextPlayerSystems : ReactiveSystem<GameEntity>
  {
    private Contexts _contexts;
    private GameContext _gameContext;

    public NextPlayerSystems(Contexts contexts) : base(contexts.game)
    {
      _contexts = contexts;
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.CurrentState));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasCurrentState && entity.currentState.type == SceneStateType.Next;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      var currentPlayerEntity = _contexts.CurrentPlayer();

      if (currentPlayerEntity.hasPossibleWalkingCells)
      {
        currentPlayerEntity.RemovePossibleWalkingCells();
        var activeFloorGameObjects = _gameContext.activeFloors.gameObjects;
        foreach (var gameObject in activeFloorGameObjects)
        {
          GameObject.Destroy(gameObject);
        }
      }

      if (_gameContext.hasActiveFloors)
      {
        _gameContext.RemoveActiveFloors();
      }
      if (_gameContext.hasAttackFloors)
      {
        _gameContext.RemoveAttackFloors();
      }

      _gameContext.ReplacePreviousState(SceneStateType.PlayerMenu);
      _gameContext.ReplaceCurrentState(SceneStateType.PlayerMenu);

      var nextPlayerIndex = _gameContext.currentPlayer.index % 2 + 1;
      var nextPlayerEntity = _gameContext.GetEntityWithPlayer(nextPlayerIndex);
      _gameContext.ReplaceCurrentPlayer(nextPlayerIndex);

      var camera = _gameContext.GetGroup(GameMatcher.AllOf(GameMatcher.GameCamera)).GetSingleEntity();
      var cameraTransform = camera.gameCamera.gameObject.transform.parent;

      var mapPresenter = GameObject.FindObjectOfType<MapPresenter>();
      var map = mapPresenter.map;
      var (mapColumn, mapRow) = map.transform.position.ToVector2();

      var playerTransform = nextPlayerEntity.view.gameObject.transform.parent;
      var (playerColumn, playerRow) = nextPlayerEntity.position;

      var x = -playerColumn - mapColumn;
      var y = playerTransform.localPosition.y;
      var z = playerRow + mapRow;

      var currentPlayerPosition = currentPlayerEntity.view.gameObject.transform.position;
      var nextPlayerPosition = new Vector3(x, y, z);
      var distance = Vector3.Distance(currentPlayerPosition, nextPlayerPosition);
      
      var duration = .05f * distance;

      cameraTransform
        .DOMove(nextPlayerPosition, duration)
        .SetEase(Ease.Linear);
    }
  }
}