﻿using System.Collections.Generic;
using System.Linq;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Player
{
  public class PlayerExpectedRotationArrowMaterialSystems : ReactiveSystem<GameEntity>
  {
    private Contexts _contexts;
    private GameContext _gameContext;

    public PlayerExpectedRotationArrowMaterialSystems(Contexts contexts) : base(contexts.game)
    {
      _contexts = contexts;
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.PlayerExpectedRotation));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasPlayerExpectedRotation;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      var materialPresenter = GameObject.FindObjectOfType<MaterialPresenter>();
      var materialProvider = materialPresenter.Provider;

      var playerEntity = _contexts.CurrentPlayer();
      playerEntity.rotationArrow.eastArrow.GetComponent<Renderer>().material = materialProvider.translucentGrey;
      playerEntity.rotationArrow.westArrow.GetComponent<Renderer>().material = materialProvider.translucentGrey;
      playerEntity.rotationArrow.northArrow.GetComponent<Renderer>().material = materialProvider.translucentGrey;
      playerEntity.rotationArrow.southArrow.GetComponent<Renderer>().material = materialProvider.translucentGrey;

      switch (_gameContext.playerExpectedRotation.type)
      {
        case PlayerRotationType.East:
          playerEntity.rotationArrow.eastArrow.GetComponent<Renderer>().material = materialProvider.translucentGreen;
          break;
        case PlayerRotationType.West:
          playerEntity.rotationArrow.westArrow.GetComponent<Renderer>().material = materialProvider.translucentGreen;
          break;
        case PlayerRotationType.North:
          playerEntity.rotationArrow.northArrow.GetComponent<Renderer>().material = materialProvider.translucentGreen;
          break;
        case PlayerRotationType.South:
          playerEntity.rotationArrow.southArrow.GetComponent<Renderer>().material = materialProvider.translucentGreen;
          break;
      }
    }
  }
}