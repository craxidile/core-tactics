﻿using System;
using System.Collections.Generic;
using System.Linq;
using DG.Tweening;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Player
{
  public class PlayerTriggerSystems : ReactiveSystem<GameEntity>
  {
    private Contexts _contexts;
    private GameContext _gameContext;

    public PlayerTriggerSystems(Contexts contexts) : base(contexts.game)
    {
      _contexts = contexts;
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.WalkingGuide));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasWalkingGuide;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      var camera = _gameContext.GetGroup(GameMatcher.AllOf(GameMatcher.GameCamera)).GetSingleEntity();
      var cameraTransform = camera.gameCamera.gameObject.transform.parent;

      var mapPresenter = GameObject.FindObjectOfType<MapPresenter>();
      var map = mapPresenter.map;
      var (mapColumn, mapRow) = map.transform.position.ToVector2();

      var playerEntity = _contexts.CurrentPlayer();

      var walkingGuide = _gameContext.walkingGuide;

      var playerTransform = playerEntity.view.gameObject.transform.parent;
      var (playerColumn, playerRow) = playerEntity.position;

      var path = walkingGuide.paths[0];
      var (direction, distance) = path;
      playerEntity.ReplaceWalking(direction);
      // Debug.Log(">>distance<< " + distance);

      switch (direction)
      {
        case WalkingDirectionType.North:
          playerRow -= distance;
          break;
        case WalkingDirectionType.South:
          playerRow += distance;
          break;
        case WalkingDirectionType.East:
          playerColumn -= distance;
          break;
        case WalkingDirectionType.West:
          playerColumn += distance;
          break;
      }

      var x = -playerColumn - mapColumn; // - 0.5f;
      var y = playerTransform.localPosition.y;
      var z = playerRow + mapRow; // + 0.5f;

      var playerPosition = new Vector3(x, y, z);
      var duration = .3f * distance;
      playerTransform.DOMove(playerPosition, duration)
        .SetEase(Ease.Linear)
        .OnComplete(() =>
        {
          playerEntity.ReplacePosition((int) playerColumn, (int) playerRow);
          walkingGuide.paths.RemoveAt(0);
          if (walkingGuide.paths.Count > 0)
          {
            _gameContext.ReplaceWalkingGuide(walkingGuide.paths);
          }
          else
          {
            _gameContext.ReplaceCurrentState(SceneStateType.WalkMenu);
            playerEntity.ReplaceWalking(WalkingDirectionType.None);
            _gameContext.RemoveWalkingGuide();
          }
        });
      cameraTransform
        .DOMove(playerPosition, duration)
        .SetEase(Ease.Linear);
    }
  }
}