﻿using System.Collections.Generic;
using Entitas;
using Taiga.GameComponents;
using UnityEngine;

namespace Taiga.GameSystem.Player
{
  public class PlayerWalkingSpriteModeSystems : ReactiveSystem<GameEntity>
  {
    private GameContext _gameContext;

    public PlayerWalkingSpriteModeSystems(Contexts contexts) : base(contexts.game)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.Player, GameMatcher.Walking));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasWalking && entity.walking._directionType != WalkingDirectionType.None;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      // Debug.Log(">>animate_walking<<");
      foreach (var entity in entities)
      {
        var direction = entity.walking._directionType;
        var gameObject = entity.view.gameObject;
        var animator = gameObject.GetComponent<Animator>();
        var renderer = gameObject.GetComponent<SpriteRenderer>();

        animator.SetInteger($"State", 2);

        /*if (direction == WalkingDirection.East)
        {
          animator.SetBool($"Front", false);
          renderer.flipX = true;
        }
        else if (direction == WalkingDirection.West)
        {
          
          animator.SetBool($"Front", true);
          renderer.flipX = true;
        }
        else
        {
        */
        var degree = entity.rotation.degree;

        if (direction == WalkingDirectionType.East)
        {
          degree = (degree + 270) % 360;
        }
        else if (direction == WalkingDirectionType.West)
        {
          degree = (degree + 90) % 360;
        }
        else if (entity.walking._directionType == WalkingDirectionType.North)
        {
          degree = (degree + 180) % 360;
        }


        var isFront = degree == 0 || degree == 90;
        var isFlipped = degree == 270 || degree == 90;

        animator.SetBool($"Front", isFront);
        renderer.flipX = isFlipped;

        // }
      }
    }
  }
}