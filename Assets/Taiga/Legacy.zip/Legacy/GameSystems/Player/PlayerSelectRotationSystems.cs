﻿using System.Collections.Generic;
using System.Linq;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using UnityEngine;

namespace Taiga.GameSystem.Player
{
  public class PlayerSelectRotationSystems : ReactiveSystem<GameEntity>
  {
    private Contexts _contexts;
    private GameContext _gameContext;

    public PlayerSelectRotationSystems(Contexts contexts) : base(contexts.game)
    {
      _contexts = contexts;
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.CurrentState));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasCurrentState && entity.currentState.type == SceneStateType.Rotation;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      var cameras = GameObject.FindObjectsOfType<Camera>();
      var arrowCamera = cameras.Where(c => c != Camera.main).FirstOrDefault().gameObject;
      arrowCamera.transform.localPosition = Camera.main.gameObject.transform.localPosition.Clone();
      arrowCamera.transform.eulerAngles = Camera.main.gameObject.transform.eulerAngles.Clone();

      var playerEntity = _contexts.CurrentPlayer();
      playerEntity.rotationArrow.eastArrow.SetActive(true);
      playerEntity.rotationArrow.westArrow.SetActive(true);
      playerEntity.rotationArrow.northArrow.SetActive(true);
      playerEntity.rotationArrow.southArrow.SetActive(true);

    }
  }
}

