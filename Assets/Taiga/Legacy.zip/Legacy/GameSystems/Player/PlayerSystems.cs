﻿using Taiga.GameSystem.Player.Actions;
using Taiga.GameSystem.Player.Decorations;

namespace Taiga.GameSystem.Player
{
  public class PlayerSystems : Feature
  {
    public PlayerSystems(Contexts contexts) : base("Player")
    {
      Add(new PlayerActionSystems(contexts));
      Add(new PlayerActionSystems(contexts));
      Add(new AddPlayerSystems(contexts));
      Add(new PlayerRotationSystems(contexts));
      Add(new PlayerTriggerSystems(contexts));
      Add(new PlayerWalkingSpriteModeSystems(contexts));
      Add(new NextPlayerSystems(contexts));
      Add(new PlayerAttackSystems(contexts));
      Add(new PlayerAttackDoneSystems(contexts));
      Add(new PlayerSelectRotationSystems(contexts));
      Add(new PlayerExpectedRotationArrowMaterialSystems(contexts));
      Add(new PlayerDecorationVisibilitySystems(contexts));
    }
  }
}