﻿using System.Collections.Generic;
using Entitas;
using Taiga.GameComponents;
using UnityEngine;

namespace Taiga.GameSystem.Player
{
  public class PlayerRotationSystems : ReactiveSystem<GameEntity>
  {
    private GameContext _gameContext;

    public PlayerRotationSystems(Contexts contexts) : base(contexts.game)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(
        GameMatcher.AllOf(GameMatcher.Player)
          .AnyOf(GameMatcher.Rotation, GameMatcher.Walking)
      );
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasRotation && entity.hasWalking && entity.walking._directionType == WalkingDirectionType.None;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      // Debug.Log(">>adjust_player_position<<");
      foreach (var entity in entities)
      {
        var gameObject = entity.view.gameObject;
        var degree = entity.rotation.degree;

        bool isFront;
        bool isFlipped;

        if (!entity.playerOld.isOpponent)
        {
          isFront = degree == 0 || degree == 90;
          isFlipped = degree == 270 || degree == 90;
        }
        else
        {
          isFront = degree == 180 || degree == 270;
          isFlipped = degree == 90 || degree == 270;
        }

        var animator = gameObject.GetComponent<Animator>();
        animator.SetInteger($"State", 1);
        animator.SetBool($"Front", isFront);
        var renderer = gameObject.GetComponent<SpriteRenderer>();
        renderer.flipX = isFlipped;
      }
    }
  }
}