﻿using System;
using System.Collections.Generic;
using System.Linq;
using DG.Tweening;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Player
{
  public class PlayerAttackDoneSystems : ReactiveSystem<GameEntity>
  {
    private GameContext _gameContext;

    public PlayerAttackDoneSystems(Contexts contexts) : base(contexts.game)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.CurrentState));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasCurrentState && entity.currentState.type == SceneStateType.AttackDone;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      var camera = _gameContext.GetGroup(GameMatcher.AllOf(GameMatcher.GameCamera)).GetSingleEntity();
      DOTween.To(
        () => camera.gameCamera.gameObject.orthographicSize,
        x => { camera.gameCamera.gameObject.orthographicSize = x; },
        3f,
        .2f
      ).SetEase(Ease.OutCubic);

      var mainLight = GameObject.FindObjectOfType<LightPresenter>().mainLight;
      DOTween.To(
        () => mainLight.intensity,
        x => { mainLight.intensity = x; },
        1f,
        .2f
      ).SetEase(Ease.OutCubic);

      var gameEntity = _gameContext.GetGroup(GameMatcher.AllOf(GameMatcher.CurrentPlayer)).GetSingleEntity();
      var playerEntities = _gameContext.GetGroup(GameMatcher.AllOf(GameMatcher.Player));
      // Debug.Log(">>game<< " + _context.GetGroup(GameMatcher.AllOf(GameMatcher.CurrentPlayer)).count);
      
      foreach (var e in entities)
      {
        foreach (var playerEntity in playerEntities)
        {
          var gameObject = playerEntity.view.gameObject;
          var animator = gameObject.GetComponent<Animator>();
          var renderer = gameObject.GetComponent<SpriteRenderer>();
          if (playerEntity.playerOld.index == gameEntity.currentPlayer.index)
          {
            animator.SetInteger($"State", 1);
          }
          else if (playerEntity.playerOld.index == -gameEntity.currentPlayer.index)
          {
            animator.SetInteger($"State", 1);
          }
          else
          {
            renderer.color = Color.white;
          }
        }
      }
      
      _gameContext.ReplaceCurrentState(SceneStateType.Next);
      // globalEntity.ReplacePlayerExpectedRotation(PlayerRotationType.None);
      // globalEntity.ReplaceCurrentState(GameStateType.Rotation);
    }
  }
}