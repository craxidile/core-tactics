﻿using System.Collections.Generic;
using Entitas;
using UnityEngine;

namespace Taiga.GameSystem.Startup
{
  public class CameraInitSystems : IInitializeSystem
  {
    private GameContext _gameContext;

    public CameraInitSystems(Contexts contexts)
    {
      _gameContext = contexts.game;
    }

    public void Initialize()
    {
      var camera = _gameContext.CreateEntity();
      camera.AddGameCamera(Camera.main);
      camera.isInitialized = false;
      camera.AddCameraRotation(0);
    }
  }
}