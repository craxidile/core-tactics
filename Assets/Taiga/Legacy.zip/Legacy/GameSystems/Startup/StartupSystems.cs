﻿namespace Taiga.GameSystem.Startup
{
  public class StartupSystems : Feature
  {
    public StartupSystems(Contexts contexts) : base("Startup Systems")
    {
      Add(new SceneInitSystems(contexts));
      Add(new MapInitSystems(contexts));
      Add(new PlayerInitSystems(contexts));
      Add(new CameraInitSystems(contexts));
    }
  }
}