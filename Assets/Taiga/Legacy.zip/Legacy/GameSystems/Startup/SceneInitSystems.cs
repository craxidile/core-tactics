﻿using Entitas;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using Taiga.GameProviders;
using UnityEngine;

namespace Taiga.GameSystem.Startup
{
  public class SceneInitSystems : IInitializeSystem
  {
    private readonly GameContext _gameContext;

    public SceneInitSystems(Contexts contexts)
    {
      _gameContext = contexts.game;
    }

    public void Initialize()
    {
      _gameContext.ReplaceCurrentPlayer(1);
      _gameContext.ReplacePreviousState(SceneStateType.PlayerMenu);
      _gameContext.ReplaceCurrentState(SceneStateType.PlayerMenu);
    }
  }
}