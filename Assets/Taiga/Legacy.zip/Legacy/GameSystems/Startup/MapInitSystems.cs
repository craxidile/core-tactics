﻿using Entitas;
using Taiga.Core;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Startup
{
  public class MapInitSystems : IInitializeSystem
  {
    private Contexts _contexts;

    public MapInitSystems(Contexts contexts)
    {
      _contexts = contexts;
    }

    public void Initialize()
    {
      var mapSettingsProvider = GameObject
        .FindObjectOfType<MapSettingsPresenter>()
        .provider;
      _contexts.AddProvider(mapSettingsProvider);
    }
  }
}