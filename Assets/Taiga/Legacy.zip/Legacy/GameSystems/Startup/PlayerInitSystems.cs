﻿using Entitas;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using Taiga.GameProviders;
using UnityEngine;

namespace Taiga.GameSystem.Startup
{
  public class PlayerInitSystems : IInitializeSystem
  {
    private readonly GameContext _context;

    public PlayerInitSystems(Contexts contexts)
    {
      _context = contexts.game;
    }

    public void Initialize()
    {
      var characterPresenter = GameObject.FindObjectOfType<CharacterPresenter>();
      var bannerPresenter = GameObject.FindObjectOfType<BannerPresenter>();

      var aji = _context.CreateEntity();
      aji.AddView(characterPresenter.CreateAji());
      aji.AddBanner(bannerPresenter.CreateAji());
      aji.AddPosition(2, 7);
      aji.AddPlayerOld(-1, true);
      aji.AddRotation(0);
      aji.AddWalking(WalkingDirectionType.None);

      var matoshi = _context.CreateEntity();
      matoshi.AddView(characterPresenter.CreateAji());
      matoshi.AddBanner(bannerPresenter.CreateAji());
      matoshi.AddPosition(2, 6);
      matoshi.AddPlayerOld(1, false);
      matoshi.AddRotation(0);
      matoshi.AddWalking(WalkingDirectionType.None);

      var nomoru = _context.CreateEntity();
      nomoru.AddView(characterPresenter.CreateNomoru());
      nomoru.AddBanner(bannerPresenter.CreateNomoru());
      nomoru.AddPosition(3, 7);
      nomoru.AddPlayerOld(-2, true);
      nomoru.AddRotation(0);
      nomoru.AddWalking(WalkingDirectionType.None);

      var youto = _context.CreateEntity();
      youto.AddView(characterPresenter.CreateNomoru());
      youto.AddBanner(bannerPresenter.CreateNomoru());
      youto.AddPosition(3, 6);
      youto.AddPlayerOld(2, false);
      youto.AddRotation(0);
      youto.AddWalking(WalkingDirectionType.None);
    }
  }
}