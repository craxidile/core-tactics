﻿using System.Collections.Generic;
using DG.Tweening;
using Entitas;
using Entitas.Unity;
using Taiga.GameProviders;
using UnityEngine;

namespace Taiga.GameSystem.View
{
  public class CameraRotationSystems : ReactiveSystem<InputEntity>
  {
    private InputContext _inputContext;
    private GameContext _gameContext;

    public CameraRotationSystems(Contexts contexts) : base(contexts.input)
    {
      _inputContext = contexts.input;
      _gameContext = contexts.game;
    }

    protected override ICollector<InputEntity> GetTrigger(IContext<InputEntity> context)
    {
      return context.CreateCollector(
        InputMatcher
          .AllOf(InputMatcher.ButtonDown)
          .AnyOf(InputMatcher.ButtonLeft, InputMatcher.ButtonRight)
      );
    }

    protected override bool Filter(InputEntity entity)
    {
      return entity.isButtonDown;
    }

    protected override void Execute(List<InputEntity> entities)
    {
      // Debug.Log(">>execute_camera_rotation<<");
      var players = _gameContext.GetGroup(GameMatcher.AllOf(GameMatcher.Player));
      var camera = _gameContext.GetGroup(GameMatcher.AllOf(GameMatcher.GameCamera)).GetSingleEntity();
      foreach (var entity in entities)
      {
        entity.isButtonDown = false;
        var degreeDiff = entity.isButtonLeft ? 90 : 270;
        var endDegree = (camera.cameraRotation.degree + degreeDiff) % 360;
        var cameraTransform = camera.gameCamera.gameObject.transform.parent;
        // cameraTransform.Rotate(cameraTransform.up, entity.isButtonLeft ? -90 : 90);
        cameraTransform.DORotate(new Vector3(0, endDegree, 0), .3f);
        camera.ReplaceCameraRotation(endDegree);

        foreach (var player in players)
        {
          DOTween.To(x => { }, 0, 1, 0.1f)
            .OnComplete(() => player.ReplaceRotation(endDegree));
          var playerTransform = player.view.gameObject.transform.parent;
          // playerTransform.Rotate(cameraTransform.up, entity.isButtonLeft ? -90 : 90);
          playerTransform.DORotate(new Vector3(0, endDegree, 0), .3f);
        }
      }
    }
  }
}