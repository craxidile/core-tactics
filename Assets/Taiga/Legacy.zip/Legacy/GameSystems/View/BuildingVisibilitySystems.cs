﻿using System.Collections.Generic;
using DG.Tweening;
using Entitas;
using Entitas.Unity;
using Taiga.GamePresenters;
using Taiga.GameProviders;
using UnityEngine;

namespace Taiga.GameSystem.View
{
  public class BuildingVisibilitySystems : ReactiveSystem<GameEntity>
  {
    private GameContext _gameContext;

    public BuildingVisibilitySystems(Contexts contexts) : base(contexts.game)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.GameCamera, GameMatcher.CameraRotation));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasCameraRotation;
    }

    private void CallBack()
    {
    }

    protected override void Execute(List<GameEntity> entities)
    {
      var buildingPresenter = GameObject.FindObjectOfType<BuildingPresenter>();
      var buildings = buildingPresenter.buildings;

      var treePresenter = GameObject.FindObjectOfType<TreePresenter>();
      var trees = treePresenter.trees;

      var visibilities = new[] {true, true, true};
      foreach (var entity in entities)
      {
        var degree = entity.cameraRotation.degree;
        // Debug.Log(">>degree<< " + degree);
        if (degree == 0)
        {
          visibilities = new[] {true, true, false};
        }

        if (degree == 90)
        {
          visibilities = new[] {false, true, true};
        }
        else if (degree == 180)
        {
          visibilities = new[] {false, false, true};
        }
        else if (degree == 270)
        {
          visibilities = new[] {true, false, false};
        }
      }

      for (var i = 0; i < buildings.Length; i++)
      {
        var visible = visibilities[i];
        SetObjectVisible(buildings[i], visible);
        SetObjectVisible(trees[i], visible);
      }
    }

    private void SetObjectVisible(GameObject gameObject, bool visible)
    {
      if (gameObject == null)
      {
        return;
      }

      if (visible)
      {
        DOTween.To(x => { }, 0, 1, 0.15f)
          .OnComplete(() => { gameObject.SetActive(true); });
      }
      else
      {
        gameObject.SetActive(false);
      }
    }
  }
}