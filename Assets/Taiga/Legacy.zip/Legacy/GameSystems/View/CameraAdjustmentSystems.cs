﻿using System;
using System.Collections.Generic;
using DG.Tweening;
using Entitas;
using UnityEngine;

namespace Taiga.GameSystem.View
{
  public class CameraAdjustmentSystems : ReactiveSystem<GameEntity>
  {
    private GameContext _gameContext;

    public CameraAdjustmentSystems(Contexts contexts) : base(contexts.game)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.CurrentPlayer));
    }

    protected override bool Filter(GameEntity entity)
    {
      if (!entity.hasCurrentPlayer)
      {
        return false;
      }

      var camera = _gameContext.GetGroup(GameMatcher.AllOf(GameMatcher.GameCamera)).GetSingleEntity();
      if (entity.currentPlayer.index == 0)
      {
        return false;
      }

      var player = _gameContext.GetEntityWithPlayer(entity.currentPlayer.index);
      if (!player.hasView)
      {
        return false;
      }

      // Debug.Log(">>is_camera_null<< " + (camera == null));
      // Debug.Log(">>is_player_null<< " + entity.currentPlayer.index + ", " + (player == null));
      return camera.gameCamera.gameObject.transform.parent.position
        - player.view.gameObject.transform.parent.position != Vector3.zero;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      // Debug.Log(">>adjust_camera<<");
      var camera = _gameContext.GetGroup(GameMatcher.AllOf(GameMatcher.GameCamera)).GetSingleEntity();
      GameEntity player = null;
      foreach (var entity in entities)
      {
        player = _gameContext.GetEntityWithPlayer(entity.currentPlayer.index);
      }

      if (player == null)
      {
        return;
      }

      var cameraTransform = camera.gameCamera.gameObject.transform;
      var playerTransform = player.view.gameObject.transform;

      if (!camera.isInitialized)
      {
        cameraTransform.parent.position = playerTransform.position;
        cameraTransform.LookAt(playerTransform);
        camera.isInitialized = true;
      }
      else
      {
        var distance = Vector3.Distance(cameraTransform.parent.position, playerTransform.position);
        cameraTransform.parent
          .DOMove(playerTransform.position, Math.Max(0.35f, distance * 0.13f))
          .SetEase(Ease.Linear);
        // cameraTransform.DOLookAt(playerTransform.position, .2f);
      }
    }
  }
}