﻿namespace Taiga.GameSystem.View
{
  public class ViewSystems : Feature
  {
    public ViewSystems(Contexts contexts) : base("View Systems")
    {
      Add(new CameraRotationSystems(contexts));
      Add(new CameraAdjustmentSystems(contexts));
      Add(new BuildingVisibilitySystems(contexts));
    }
  }
}