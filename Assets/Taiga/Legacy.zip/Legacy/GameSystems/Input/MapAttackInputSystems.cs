﻿using System;
using System.Collections.Generic;
using System.Linq;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using UnityEngine;
using UnityEngine.Assertions;

namespace Taiga.GameSystem.Input
{
  public class MapAttackInputSystems : ReactiveSystem<InputEntity>
  {
    private Contexts _contexts;
    private GameContext _gameContext;
    private InputContext _inputContext;

    public MapAttackInputSystems(Contexts contexts) : base(contexts.input)
    {
      _contexts = contexts;
      _gameContext = contexts.game;
      _inputContext = contexts.input;
    }

    protected override ICollector<InputEntity> GetTrigger(IContext<InputEntity> context)
    {
      return context.CreateCollector(InputMatcher.AllOf(InputMatcher.MouseLeft, InputMatcher.MouseDown));
    }

    protected override bool Filter(InputEntity entity)
    {
      return entity.hasMouseDown;
    }

    protected override void Execute(List<InputEntity> entities)
    {
      var entity = entities.FirstOrDefault();
      if (entity == null)
      {
        return;
      }
      if (_gameContext.currentState.type != SceneStateType.Attack)
      {
        return;
      }

      var map = GameObject.FindObjectOfType<MapPresenter>();
      var floor = map.floor;

      var camera = Camera.main;
      Assert.IsFalse(camera == null, "Camera cannot be null.");
      var screenPosition = entity.mouseDown.position;
      var ray = camera.ScreenPointToRay(screenPosition);

      RaycastHit hit;
      if (Physics.Raycast(ray, out hit, 500))
      {
        var hitObject = hit.collider.gameObject;
        if (hitObject == floor)
        {
          var (posOriginX, posOriginY) = floor.transform.localPosition.ToVector2();
          var (posX, posY) = hit.point.ToVector2();
          var column = (int) Math.Max(0, Math.Floor(posOriginX - posX + 0.5f));
          var row = (int) Math.Max(0, Math.Floor(posOriginY + posY));

          Debug.Log($">>current_state<< {_gameContext.currentState.type}");
          _gameContext.ReplaceAttackPosition(column, row);
        }
      }

      entity.RemoveMouseDown();
    }
  }
}