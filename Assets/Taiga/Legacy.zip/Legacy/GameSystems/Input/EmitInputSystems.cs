﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Entitas;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using UnityEngine;
using UnityEngine.EventSystems;

namespace Taiga.GameSystem.Input
{
  public class EmitInputSystems : IInitializeSystem, IExecuteSystem
  {
    private InputContext _context;

    public EmitInputSystems(Contexts contexts)
    {
      _context = contexts.input;
    }

    public void Initialize()
    {
      _context.isMouseLeft = true;
      _context.isMouseCursor = true;
      _context.isButtonQ = true;
      _context.isButtonA = true;
      _context.isButtonZ = true;
      _context.isButtonLeft = true;
      _context.isButtonRight = true;
      _context.isButtonUpArrow = true;
      _context.isButtonDownArrow = true;
    }

    public void Execute()
    {
      if (EventSystem.current.IsPointerOverGameObject())
      {
        var pointerEventData = new PointerEventData(EventSystem.current);
        pointerEventData.position = UnityEngine.Input.mousePosition;
        var rayCastResults = new List<RaycastResult>();
        EventSystem.current.RaycastAll(pointerEventData, rayCastResults);
        var gameObject = rayCastResults.Count > 0 ? rayCastResults.FirstOrDefault().gameObject : null;
        if (!_context.mouseCursorEntity.hasMouseOver || _context.mouseCursorEntity.mouseOver.gameObject != gameObject)
        {
          _context.mouseCursorEntity.ReplaceMouseOver(gameObject);
          var soundPresenter = GameObject.FindObjectOfType<SoundPresenter>();
          soundPresenter.Play(SoundEffectType.MouseOver);
        }
        else if (UnityEngine.Input.GetMouseButtonDown(0))
        {
          Debug.Log(">>mouse_press<< " + gameObject);
          _context.mouseCursorEntity.ReplaceMousePress(gameObject);
          var soundPresenter = GameObject.FindObjectOfType<SoundPresenter>();
          soundPresenter.Play(SoundEffectType.Click);
        }
      }
      else if (!_context.mouseCursorEntity.hasMouseOver || _context.mouseCursorEntity.mouseOver.gameObject != null)
      {
        _context.mouseCursorEntity.ReplaceMouseOver(null);
      }

      if (UnityEngine.Input.GetMouseButtonDown(0))
      {
        _context.mouseLeftEntity.ReplaceMouseDown(UnityEngine.Input.mousePosition);
      }
      else
      {
        _context.mouseCursorEntity.ReplaceMouseRollOver(UnityEngine.Input.mousePosition);
      }

      if (UnityEngine.Input.GetKeyDown(KeyCode.Q))
      {
        _context.buttonQEntity.isButtonDown = true;
      }
      else if (UnityEngine.Input.GetKeyDown(KeyCode.A))
      {
        _context.buttonAEntity.isButtonDown = true;
      }
      else if (UnityEngine.Input.GetKeyDown(KeyCode.Z))
      {
        _context.buttonZEntity.isButtonDown = true;
      }
      else if (UnityEngine.Input.GetKeyDown(KeyCode.LeftArrow))
      {
        _context.buttonLeftEntity.isButtonDown = true;
      }
      else if (UnityEngine.Input.GetKeyDown(KeyCode.RightArrow))
      {
        _context.buttonRightEntity.isButtonDown = true;
      }
      else if (UnityEngine.Input.GetKeyDown(KeyCode.UpArrow))
      {
        _context.buttonUpArrowEntity.isButtonDown = true;
      }
      else if (UnityEngine.Input.GetKeyDown(KeyCode.DownArrow))
      {
        _context.buttonDownArrowEntity.isButtonDown = true;
      }
    }
  }
}