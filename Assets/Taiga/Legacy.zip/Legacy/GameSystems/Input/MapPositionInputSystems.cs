﻿using System;
using System.Collections.Generic;
using System.Linq;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Input
{
  public class MapPositionInputSystems : ReactiveSystem<InputEntity>
  {
    private Contexts _contexts;
    private GameContext _gameContext;

    public MapPositionInputSystems(Contexts contexts) : base(contexts.input)
    {
      _contexts = contexts;
      _gameContext = contexts.game;
    }

    protected override ICollector<InputEntity> GetTrigger(IContext<InputEntity> context)
    {
      return context.CreateCollector(InputMatcher.AllOf(InputMatcher.MouseLeft, InputMatcher.MouseDown));
    }

    protected override bool Filter(InputEntity entity)
    {
      return entity.hasMouseDown;
    }

    protected override void Execute(List<InputEntity> entities)
    {
      var entity = entities.FirstOrDefault();
      if (entity == null)
      {
        return;
      }

      if (_gameContext.currentState.type != SceneStateType.Move)
      {
        return;
      }

      var map = GameObject.FindObjectOfType<MapPresenter>();
      var floor = map.floor;

      var cameraEntity = _gameContext.GetGroup(GameMatcher.AllOf(GameMatcher.GameCamera)).GetSingleEntity();
      var camera = cameraEntity.gameCamera.gameObject;
      var screenPosition = entity.mouseDown.position;
      var ray = camera.ScreenPointToRay(screenPosition);
      // Debug.DrawLine(ray.origin, ray.origin + ray.direction * 100, Color.red);

      RaycastHit hit;
      if (Physics.Raycast(ray, out hit, 500))
      {
        var hitObject = hit.collider.gameObject;
        // Debug.Log(">>game_object<< " + hitObject.tag);
        if (hitObject == floor)
        {
          var soundPresenter = GameObject.FindObjectOfType<SoundPresenter>();
          soundPresenter.Play(SoundEffectType.Click);

          var (posOriginX, posOriginY) = floor.transform.localPosition.ToVector2();
          var (posX, posY) = hit.point.ToVector2();
          var column = (int) Math.Max(0, Math.Floor(posOriginX - posX + 0.5f));
          var row = (int) Math.Max(0, Math.Floor(posOriginY + posY));
          // Debug.Log(">>move_player<< " + column + ", " + row);

          var playerEntity = _contexts.CurrentPlayer();
          if (!playerEntity.hasPossibleWalkingCells)
          {
            return;
          }

          if (playerEntity.possibleWalkingCells.cells.Contains(new Tuple<int, int>(column, row)))
          {
            _gameContext.ReplaceExpectedPosition(column, row);
          }
        }
      }

      entity.RemoveMouseDown();
    }
  }
}