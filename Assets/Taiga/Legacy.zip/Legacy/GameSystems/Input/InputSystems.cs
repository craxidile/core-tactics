﻿using UnityEngine.UIElements;

namespace Taiga.GameSystem.Input
{
  public class InputSystems : Feature
  {
    public InputSystems(Contexts contexts) : base("Input Systems")
    {
      Add(new EmitInputSystems(contexts));
      Add(new MapPositionInputSystems(contexts));
      Add(new MapAttackInputSystems(contexts));
      Add(new MapRotationInputSystems(contexts));
    }
  }
}