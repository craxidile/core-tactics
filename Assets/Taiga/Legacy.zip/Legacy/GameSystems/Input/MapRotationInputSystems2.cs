﻿using System;
using System.Collections.Generic;
using System.Linq;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using Taiga.Tools;
using UnityEngine;
using UnityEngine.PlayerLoop;

namespace Taiga.GameSystem.Input
{
  public class MapRotationInputSystems : ReactiveSystem<InputEntity>
  {
    private Contexts _contexts;
    private GameContext _gameContext;
    private InputContext _inputContext;

    public MapRotationInputSystems(Contexts contexts) : base(contexts.input)
    {
      _contexts = contexts;
      _gameContext = contexts.game;
      _inputContext = contexts.input;
    }

    protected override ICollector<InputEntity> GetTrigger(IContext<InputEntity> context)
    {
      return context.CreateCollector(InputMatcher.AllOf(InputMatcher.MouseCursor, InputMatcher.MouseRollOver));
    }

    protected override bool Filter(InputEntity entity)
    {
      return entity.hasMouseRollOver;
    }

    protected override void Execute(List<InputEntity> entities)
    {
      var entity = entities.FirstOrDefault();
      if (entity == null)
      {
        return;
      }

      if (_gameContext.currentState.type != SceneStateType.Rotation)
      {
        return;
      }

      var mapPresenter = GameObject.FindObjectOfType<MapPresenter>();
      var floor = mapPresenter.floor;

      var cameraEntity = _gameContext.GetGroup(GameMatcher.AllOf(GameMatcher.GameCamera)).GetSingleEntity();
      var camera = cameraEntity.gameCamera.gameObject;
      var screenPosition = entity.mouseRollOver.position;
      var ray = camera.ScreenPointToRay(screenPosition);

      var playerEntity = _contexts.CurrentPlayer();
      var (playerColumn, playerRow) = playerEntity.position;

      var cells = _contexts.FindPlayerRotationCells();

      RaycastHit hit;
      if (Physics.Raycast(ray, out hit, 500))
      {
        var hitObject = hit.collider.gameObject;
        // Debug.Log(">>game_object<< " + hitObject.tag);
        if (hitObject == floor)
        {
          var (posOriginX, posOriginY) = floor.transform.localPosition.ToVector2();
          var (posX, posY) = hit.point.ToVector2();
          var column = (int) Math.Max(0, Math.Floor(posOriginX - posX + 0.5f));
          var row = (int) Math.Max(0, Math.Floor(posOriginY + posY));

          if (cells.Contains(Tuple.Create(column, row)))
          {
            if (column < playerColumn && _gameContext.playerExpectedRotation.type != PlayerRotationType.East)
            {
              Debug.Log(">>east<<");
              _gameContext.ReplacePlayerExpectedRotation(PlayerRotationType.East);
            }
            else if (column > playerColumn && _gameContext.playerExpectedRotation.type != PlayerRotationType.West)
            {
              Debug.Log(">>west<<");
              _gameContext.ReplacePlayerExpectedRotation(PlayerRotationType.West);
            }
            else if (row < playerRow && _gameContext.playerExpectedRotation.type != PlayerRotationType.North)
            {
              Debug.Log(">>north<<");
              _gameContext.ReplacePlayerExpectedRotation(PlayerRotationType.North);
            }
            else if (row > playerRow && _gameContext.playerExpectedRotation.type != PlayerRotationType.South)
            {
              Debug.Log(">>south<<");
              _gameContext.ReplacePlayerExpectedRotation(PlayerRotationType.South);
            }
          }
        }
      }

      entity.RemoveMouseRollOver();
    }
  }
}