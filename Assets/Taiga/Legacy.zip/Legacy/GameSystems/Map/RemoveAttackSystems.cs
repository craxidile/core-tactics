﻿using System;
using System.Collections.Generic;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using Taiga.Tools;
using UnityEngine;

namespace Taiga.GameSystem.Map
{
  public class RemoveAttackSystem : ReactiveSystem<GameEntity>
  {
    private GameContext _gameContext;

    public RemoveAttackSystem(Contexts contexts) : base(contexts.game)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.AttackPosition));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasAttackPosition && _gameContext.hasAttackFloors &&
             _gameContext.currentState.type == SceneStateType.Attack;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      var cells = _gameContext.attackFloors.gameObjects;
      foreach (var cell in cells)
      {
        GameObject.Destroy(cell);
      }
    }
  }
}