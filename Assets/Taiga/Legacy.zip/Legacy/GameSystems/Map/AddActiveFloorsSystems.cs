﻿using System;
using System.Collections.Generic;
using Entitas;
using Taiga.Extensions;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Map
{
  public class AddActiveFloorsSystems : ReactiveSystem<GameEntity>
  {
    private GameContext _gameContext;

    public AddActiveFloorsSystems(Contexts contexts) : base(contexts.game)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.PossibleWalkingCells));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasPossibleWalkingCells && !_gameContext.hasActiveFloors;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      if (_gameContext.hasActiveFloors)
      {
        var floorObjects = _gameContext.activeFloors.gameObjects;
        foreach (var floorObject in floorObjects)
        {
          GameObject.Destroy(floorObject);
        }
      }

      var decorationPresenter = GameObject.FindObjectOfType<DecorationPresenter>();

      var mapPresenter = GameObject.FindObjectOfType<MapPresenter>();
      var playerFloor = mapPresenter.playerFloor;
      var map = mapPresenter.map;
      var (mapColumn, mapRow) = map.transform.position.ToVector2();

      var cells = _gameContext.possibleWalkingCells.cells;

      var activeFloorList = new List<GameObject>();

      foreach (var destination in cells)
      {
        var (column, row) = destination;
        var x = -column - mapColumn;
        var z = row + mapRow;
        var walkingFloor = decorationPresenter.CreateWalkingFloor();
        walkingFloor.transform.position = new Vector3(x, 0.01f, z);
        walkingFloor.transform.SetParent(playerFloor.transform, true);
        activeFloorList.Add(walkingFloor);
        Debug.Log($">>add_walking_floor_at<< {column} {row}");
      }

      _gameContext.ReplaceActiveFloors(activeFloorList.ToArray());
    }
  }
}