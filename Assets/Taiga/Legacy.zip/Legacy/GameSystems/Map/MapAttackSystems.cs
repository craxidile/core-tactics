﻿using System;
using System.Collections.Generic;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using Taiga.Tools;
using UnityEngine;

namespace Taiga.GameSystem.Map
{
  public class MapAttackSystem : ReactiveSystem<GameEntity>
  {
    private Contexts _contexts;
    private GameContext _gameContext;

    public MapAttackSystem(Contexts contexts) : base(contexts.game)
    {
      _contexts = contexts;
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.CurrentState));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasCurrentState && entity.currentState.type == SceneStateType.Attack;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      var decorationPresenter = GameObject.FindObjectOfType<DecorationPresenter>();

      var mapPresenter = GameObject.FindObjectOfType<MapPresenter>();
      var playerFloor = mapPresenter.playerFloor;
      var mapObject = mapPresenter.map;
      var (mapColumn, mapRow) = mapObject.transform.position.ToVector2();

      // Determine whether the current player is able to attack
      var cells = _contexts.FindAdjacentCells();
      var attackFloorList = new List<GameObject>();

      foreach (var destination in cells)
      {
        var (column, row) = destination;
        var x = -column - mapColumn;
        var z = row + mapRow;
        var attackFloor = decorationPresenter.CreateAttackFloor();
        attackFloor.transform.position = new Vector3(x, 0.01f, z);
        attackFloor.transform.SetParent(playerFloor.transform, true);
        attackFloorList.Add(attackFloor);
        Debug.Log($">>add_attack_floor_at<< {column} {row}");
      }

      _gameContext.ReplaceAttackFloors(attackFloorList.ToArray());
    }
  }
}