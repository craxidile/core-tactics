﻿namespace Taiga.GameSystem.Map
{
  public class MapSystems : Feature
  {
    public MapSystems(Contexts contexts) : base("Position Systems")
    {
      Add(new PathCalculationSystems(contexts));
      Add(new PathFinderSystems(contexts));
      Add(new AddActiveFloorsSystems(contexts));
      Add(new RemoveActiveFloorSystem(contexts));
      Add(new MapAttackSystem(contexts));
      Add(new RemoveAttackSystem(contexts));
    }
  }
}