﻿using System;
using System.Collections.Generic;
using System.Linq;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using Taiga.Tools;
using UnityEngine;
using UnityEngine.UI;

namespace Taiga.GameSystem.Map
{
  public class PathCalculationSystems : ReactiveSystem<GameEntity>
  {
    private Contexts _contexts;
    private GameContext _gameContext;

    public PathCalculationSystems(Contexts contexts) : base(contexts.game)
    {
      _contexts = contexts;
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.ExpectedPosition));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasExpectedPosition;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      var playerEntity = _contexts.CurrentPlayer();

      var possibleCells = playerEntity.possibleWalkingCells.cells;
      var (playerColumn, playerRow) = playerEntity.position;
      var (expectedColumn, expectedRow) = _gameContext.expectedPosition;
      // Debug.Log(">>expected_position<< " + expectedColumn + ", " + expectedRow);

      // var columnDiff = Math.Max(expectedColumn, 0) - playerColumn;
      // var rowDiff = Math.Max(expectedRow, 0) - playerRow;

      var paths = new List<Tuple<WalkingDirectionType, int>>();

      // var verticalDirection = rowDiff > 0 ? WalkingDirection.South : WalkingDirection.North;
      // paths.Add(new Tuple<WalkingDirection, int>(verticalDirection, Math.Abs(rowDiff)));
      //
      // var horizontalDirection = columnDiff > 0 ? WalkingDirection.West : WalkingDirection.East;
      // paths.Add(new Tuple<WalkingDirection, int>(horizontalDirection, Math.Abs(columnDiff)));

      var origin = new Tuple<int, int>(playerColumn, playerRow);
      var destination = new Tuple<int, int>(expectedColumn, expectedRow);
      var path = MapTools.FindPath(possibleCells, origin, destination);
      if (path == null)
      {
        return;
      }

      var currentColumn = playerColumn;
      var currentRow = playerRow;
      foreach (var cell in path)
      {
        var (nextColumn, nextRow) = cell;
        var columnDiff = nextColumn - currentColumn;
        var rowDiff = nextRow - currentRow;
        // Debug.Log($">>next_cell<< [{nextColumn}, {nextRow}] >>column_diff<< [{columnDiff}, {rowDiff}]");

        if (columnDiff > 0)
        {
          paths.Add(new Tuple<WalkingDirectionType, int>(WalkingDirectionType.West, columnDiff));
        }
        else if (columnDiff < 0)
        {
          paths.Add(new Tuple<WalkingDirectionType, int>(WalkingDirectionType.East, -columnDiff));
        }

        if (rowDiff > 0)
        {
          paths.Add(new Tuple<WalkingDirectionType, int>(WalkingDirectionType.South, rowDiff));
        }
        else if (rowDiff < 0)
        {
          paths.Add(new Tuple<WalkingDirectionType, int>(WalkingDirectionType.North, -rowDiff));
        }

        currentColumn = nextColumn;
        currentRow = nextRow;
      }

      _gameContext.ReplaceWalkingGuide(paths);
    }
  }
}