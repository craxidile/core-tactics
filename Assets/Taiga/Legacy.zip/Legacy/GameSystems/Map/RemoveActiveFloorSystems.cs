﻿using System;
using System.Collections.Generic;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using UnityEngine;

namespace Taiga.GameSystem.Map
{
  public class RemoveActiveFloorSystem : ReactiveSystem<GameEntity>
  {
    private GameContext _gameContext;

    public RemoveActiveFloorSystem(Contexts contexts) : base(contexts.game)
    {
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.CurrentState));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.hasCurrentState && entity.currentState.type == SceneStateType.PlayerMenu && 
             _gameContext.hasActiveFloors;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      Debug.Log(">>remove_active_floors<<");
      var floorObjects = _gameContext.activeFloors.gameObjects;
      foreach (var floorObject in floorObjects)
      {
        GameObject.Destroy(floorObject);
      }
    }
  }
}