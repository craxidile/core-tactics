﻿using System;
using System.Collections.Generic;
using System.Linq;
using Entitas;
using Taiga.Extensions;
using Taiga.GameComponents;
using Taiga.GamePresenters;
using Taiga.Tools;
using UnityEngine;

namespace Taiga.GameSystem.Map
{
  public class PathFinderSystems : ReactiveSystem<GameEntity>
  {
    private Contexts _contexts;
    private GameContext _gameContext;

    public PathFinderSystems(Contexts contexts) : base(contexts.game)
    {
      _contexts = contexts;
      _gameContext = contexts.game;
    }

    protected override ICollector<GameEntity> GetTrigger(IContext<GameEntity> context)
    {
      return context.CreateCollector(GameMatcher.AllOf(GameMatcher.CurrentState));
    }

    protected override bool Filter(GameEntity entity)
    {
      return entity.currentState.type == SceneStateType.Move;
    }

    protected override void Execute(List<GameEntity> entities)
    {
      var playerEntity = _contexts.CurrentPlayer();
      Debug.Log($">>has_possible_walking_cells<< {playerEntity.hasPossibleWalkingCells}");
      if (!playerEntity.hasPossibleWalkingCells)
      {
        var cells = _contexts.FindWalkableCells(3);
        if (_gameContext.hasActiveFloors)
        {
          _gameContext.RemoveActiveFloors();
        }
        
        playerEntity.ReplacePossibleWalkingCells(cells);
        Debug.Log($">>possible_walking_cells<< {cells}");
      }
      else
      {
        playerEntity.ReplacePossibleWalkingCells(playerEntity.possibleWalkingCells.cells);
      }
    }
  }
}