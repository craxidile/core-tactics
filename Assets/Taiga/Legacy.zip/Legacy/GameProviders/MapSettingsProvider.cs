﻿using Taiga.Core;
using UnityEngine;

namespace Taiga.GameProviders
{
  [CreateAssetMenu(fileName = "Game Presents", menuName = "Provider/Map Settings/Create", order = 1)]
  public class MapSettingsProvider : ScriptableObject, IProvider
  {
    public int width;
    public int height;
  }
}