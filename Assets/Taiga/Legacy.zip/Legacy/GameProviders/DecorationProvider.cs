﻿using UnityEngine;

namespace Taiga.GameProviders
{
  [CreateAssetMenu(fileName = "Game Presents", menuName = "Provider/Decoration/Create", order = 1)]
  public class DecorationProvider : ScriptableObject
  {
    public GameObject shadow;
    public GameObject arrowDown;
    public GameObject walkingFloor;
    public GameObject attackFloor;
    public GameObject rotationArrowNorth;
    public GameObject rotationArrowEast;
    public GameObject rotationArrowWest;
    public GameObject rotationArrowSouth;
  }
}