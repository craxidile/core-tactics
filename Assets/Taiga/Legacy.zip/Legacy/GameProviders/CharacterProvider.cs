﻿using UnityEngine;

namespace Taiga.GameProviders
{
  [CreateAssetMenu(fileName = "Game Presents", menuName = "Provider/Character/Create", order = 1)]
  public class CharacterProvider : ScriptableObject
  {
    public GameObject aji;
    public GameObject nomoru;
  }
}