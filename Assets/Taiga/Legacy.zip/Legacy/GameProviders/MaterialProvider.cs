﻿using UnityEngine;

namespace Taiga.GameProviders
{
  [CreateAssetMenu(fileName = "Game Presents", menuName = "Provider/Material/Create", order = 1)]
  public class MaterialProvider : ScriptableObject
  {
    public Material translucentGrey;
    public Material translucentGreen;
  }
}