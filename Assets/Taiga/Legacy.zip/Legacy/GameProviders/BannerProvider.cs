﻿using UnityEngine;

namespace Taiga.GameProviders
{
  [CreateAssetMenu(fileName = "Game Presents", menuName = "Provider/Banner/Create", order = 1)]
  public class BannerProvider : ScriptableObject
  {
    public GameObject aji;
    public GameObject nomoru;
    public GameObject matoshi;
    public GameObject youto;
  }
}