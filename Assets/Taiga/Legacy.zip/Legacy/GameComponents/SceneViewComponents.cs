﻿using System;
using System.Collections.Generic;
using Entitas;
using Entitas.CodeGeneration.Attributes;
using UnityEngine;

namespace Taiga.GameComponents
{
  [Game, Unique]
  public class AttackFloors : IComponent
  {
    public GameObject[] gameObjects;
  }

  [Game, Unique]
  public class ActiveFloors : IComponent
  {
    public GameObject[] gameObjects;
  }
}