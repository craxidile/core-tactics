﻿using Entitas;
using Entitas.CodeGeneration.Attributes;
using UnityEngine;

namespace Taiga.GameComponents
{
  public class InputComponents
  {
    [Input, Unique]
    public class MouseLeftComponent : IComponent
    {
    }

    [Input, Unique]
    public class MouseCursorComponent : IComponent
    {
    }

    [Input, Unique]
    public class ButtonQComponent : IComponent
    {
    }

    [Input, Unique]
    public class ButtonAComponent : IComponent
    {
    }

    [Input, Unique]
    public class ButtonZComponent : IComponent
    {
    }

    [Input, Unique]
    public class ButtonLeftComponent : IComponent
    {
    }

    [Input, Unique]
    public class ButtonRightComponent : IComponent
    {
    }

    [Input, Unique]
    public class ButtonUpArrowComponent : IComponent
    {
    }

    [Input, Unique]
    public class ButtonDownArrowComponent : IComponent
    {
    }

    [Input] // , Cleanup(CleanupMode.DestroyEntity)]
    public class ButtonDownComponent : IComponent
    {
    }

    [Input] // , Cleanup(CleanupMode.DestroyEntity)]
    public class MouseOverComponent : IComponent
    {
      public GameObject gameObject;
    }

    [Input] // , Cleanup(CleanupMode.DestroyEntity)]
    public class MousePressComponent : IComponent
    {
      public GameObject gameObject;
    }

    [Input] // , Cleanup(CleanupMode.DestroyEntity)]
    public class MouseDownComponent : IComponent
    {
      public Vector2 position;
    }

    [Input]
    public class MouseRollOverComponent : IComponent
    {
      public Vector2 position;
    }
  }
}