﻿using Entitas;

namespace Taiga.GameComponents
{
  [Game]
  public class CameraRotation : IComponent
  {
    public int degree;
  }
}