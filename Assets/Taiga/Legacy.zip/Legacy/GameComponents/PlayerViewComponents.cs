﻿using System;
using Entitas;
using Entitas.CodeGeneration.Attributes;
using UnityEngine;

namespace Taiga.GameComponents
{
  [Game]
  public class Banner : IComponent
  {
    public GameObject gameObject;
  }

  [Game]
  public class Arrow : IComponent
  {
    public GameObject gameObject;
  }

  [Game]
  public class RotationArrowComponent : IComponent
  {
    public GameObject northArrow;
    public GameObject southArrow;
    public GameObject eastArrow;
    public GameObject westArrow;
  }
}