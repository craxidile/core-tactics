﻿using System;
using System.Collections.Generic;
using Entitas;
using Entitas.CodeGeneration.Attributes;
using UnityEngine;

namespace Taiga.GameComponents
{
  // TODO: Attack, Walk -50 CharacterTurn Credit
  // TODO: 1 CharacterTurn passes, + 10 CharacterTurn Credit for everyone
  // TODO: If reach 100, choose that player
  // TODO: If does not reach 100, choose the maximum

  [Game]
  public class InitializedComponent : IComponent
  {
  }

  
  
}