﻿using Entitas;

namespace Taiga.GameComponents
{
  public enum SoundEffectType
  {
    Click,
    MouseOver,
    Punch,
  };

  [Game]
  public class SoundEffect : IComponent
  {
    public SoundEffectType type;
  }
}