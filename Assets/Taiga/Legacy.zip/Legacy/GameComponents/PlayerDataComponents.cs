﻿using System;
using Entitas;
using Entitas.CodeGeneration.Attributes;
using UnityEngine;

namespace Taiga.GameComponents
{
  public enum PlayerStateType
  {
    Attacking,
    Attacked,
  };

  public class PlayerOld : IComponent
  {
    [PrimaryEntityIndex] public int index;
    public bool isOpponent;
  }

  [Game]
  public class PositionComponent : IComponent
  {
    public int column;
    public int row;

    public void Deconstruct(out int outColumn, out int outRow)
    {
      outColumn = column;
      outRow = row;
    }
  }

  [Game]
  public class Walking : IComponent
  {
    public WalkingDirectionType _directionType;
  }

  [Game]
  public class Rotation : IComponent
  {
    public int degree;
  }

  [Game]
  public class PlayerState : IComponent
  {
    public PlayerStateType type;
  }
}