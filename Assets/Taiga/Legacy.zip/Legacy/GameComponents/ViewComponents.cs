﻿using Entitas;
using Entitas.CodeGeneration.Attributes;
using UnityEngine;

namespace Taiga.GameComponents
{
  [Game, Cleanup(CleanupMode.DestroyEntity)]
  public class ViewComponent : IComponent
  {
    public GameObject gameObject;
  }

  public class GameCameraComponent : IComponent
  {
    public Camera gameObject;
  }
}