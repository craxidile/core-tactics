﻿using System;
using System.Collections.Generic;
using Entitas;
using Entitas.CodeGeneration.Attributes;
using UnityEngine;

namespace Taiga.GameComponents
{
  public enum SceneStateType
  {
    PlayerMenu,
    WalkMenu,
    Move,
    Attack,
    AttackDone,
    Special,
    Rotation,
    Wait,
    Next,
  }

  public enum WalkingDirectionType
  {
    None,
    North,
    West,
    South,
    East,
  };

  public enum PlayerRotationType
  {
    None,
    North,
    West,
    South,
    East,
  };

  [Game, Unique]
  public class CurrentPlayer : IComponent
  {
    public int index;
  }

  [Game, Unique]
  public class CurrentState : IComponent
  {
    public SceneStateType type;
  }

  [Game, Unique]
  public class PreviousState : IComponent
  {
    public SceneStateType type;
  }

  [Game, Unique]
  public class ExpectedPosition : IComponent
  {
    public int column;
    public int row;

    public void Deconstruct(out int outColumn, out int outRow)
    {
      outColumn = column;
      outRow = row;
    }
  }

  [Game, Unique]
  public class AttackPosition : IComponent
  {
    public int column;
    public int row;

    public void Deconstruct(out int outColumn, out int outRow)
    {
      outColumn = column;
      outRow = row;
    }
  }

  [Game, Unique]
  public class PossibleWalkingCells : IComponent
  {
    public Tuple<int, int>[] cells;
  }

  [Game, Unique]
  public class WalkingGuide : IComponent
  {
    public List<Tuple<WalkingDirectionType, int>> paths;
  }

  [Game, Unique]
  public class PlayerExpectedRotation : IComponent
  {
    public PlayerRotationType type;
  }
}