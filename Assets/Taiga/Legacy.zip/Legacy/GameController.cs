﻿using Entitas;
using Taiga.GameSystem.Input;
using Taiga.GameSystem.Map;
using Taiga.GameSystem.Player;
using Taiga.GameSystem.Startup;
using Taiga.GameSystem.Ui;
using Taiga.GameSystem.View;

namespace Taiga
{
    public class _GameController
    {
        private readonly Systems _systems;

        public _GameController(Contexts contexts)
        {
            _systems = new _MainSystems(contexts);
        }

        public void Initialise()
        {
            _systems.Initialize();
        }

        public void Execute()
        {
            _systems.Execute();
            _systems.Cleanup();
        }

        public void TearDown()
        {
            _systems.TearDown();
        }
    }

    public class _MainSystems : Feature
    {
        public _MainSystems(Contexts contexts) : base("Systems")
        {
            Add(new StartupSystems(contexts));
            Add(new PlayerSystems(contexts));
            Add(new ViewSystems(contexts));
            Add(new InputSystems(contexts));
            Add(new MapSystems(contexts));
            Add(new UiSystems(contexts));
        }
    }
}