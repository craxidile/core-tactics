﻿using Taiga;
using UnityEngine;

public class Main : MonoBehaviour
{
  _GameController gameController;

  private void Awake()
  {
    var contexts = Contexts.sharedInstance;
    gameController = new _GameController(contexts);
  }

  void Start()
  {
    gameController.Initialise();
  }

  void Update()
  {
    gameController.Execute();
  }

  void Destroy()
  {
    gameController.TearDown();
  }
}