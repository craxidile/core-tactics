﻿using UnityEngine;

namespace Taiga.GamePresenters
{
  public class MapPresenter : MonoBehaviour
  {
    public GameObject map;
    public GameObject floor;
    public GameObject playerFloor;
  }
}