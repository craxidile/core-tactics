﻿using Taiga.GameProviders;
using UnityEngine;

namespace Taiga.GamePresenters
{
  public class UiPresenter : MonoBehaviour
  {
    public GameObject canvas;
  }
}