﻿using Taiga.GameProviders;
using UnityEngine;

namespace Taiga.GamePresenters
{
  public class MaterialPresenter : MonoBehaviour
  {
    public ScriptableObject materialProvider;

    public MaterialProvider Provider => materialProvider as MaterialProvider;
  }
}