﻿using Taiga.GameProviders;

namespace Taiga.GamePresenters
{
  public class MapSettingsPresenter : MonoProvider<MapSettingsProvider>
  {
  }
}