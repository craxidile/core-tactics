﻿using Taiga.GameProviders;
using UnityEngine;

namespace Taiga.GamePresenters
{
  public class TreePresenter : MonoBehaviour
  {
    public GameObject[] trees;
  }
}