﻿using Taiga.GameProviders;
using UnityEngine;

namespace Taiga.GamePresenters
{
  public class BuildingPresenter : MonoBehaviour
  {
    public GameObject[] buildings;
  }
}