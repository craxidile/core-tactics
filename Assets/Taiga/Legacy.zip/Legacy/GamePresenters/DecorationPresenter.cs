﻿using Taiga.GameProviders;
using UnityEngine;

namespace Taiga.GamePresenters
{
  public class DecorationPresenter : MonoBehaviour
  {
    public ScriptableObject decorationProvider;

    public DecorationProvider GetProvider()
    {
      return decorationProvider as DecorationProvider;
    }

    public GameObject CreateShadow()
    {
      return Instantiate(GetProvider().shadow);
    }

    public GameObject CreateArrowDown()
    {
      return Instantiate(GetProvider().arrowDown);
    }

    public GameObject CreateWalkingFloor()
    {
      return Instantiate(GetProvider().walkingFloor);
    }

    public GameObject CreateAttackFloor()
    {
      return Instantiate(GetProvider().attackFloor);
    }

    public GameObject CreateRotationArrowSouth()
    {
      return Instantiate(GetProvider().rotationArrowSouth);
    }
    
    public GameObject CreateRotationArrowNorth()
    {
      return Instantiate(GetProvider().rotationArrowNorth);
    }
    
    public GameObject CreateRotationArrowEast()
    {
      return Instantiate(GetProvider().rotationArrowEast);
    }
    
    public GameObject CreateRotationArrowWest()
    {
      return Instantiate(GetProvider().rotationArrowWest);
    }
  }
}