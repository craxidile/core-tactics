﻿using Taiga.GameProviders;
using UnityEngine;

namespace Taiga.GamePresenters
{
  public class BannerPresenter : MonoBehaviour
  {
    public ScriptableObject bannerProvider;

    public BannerProvider GetProvider()
    {
      return bannerProvider as BannerProvider;
    }

    public GameObject CreateAji()
    {
      return Instantiate(GetProvider().aji);
    }

    public GameObject CreateNomoru()
    {
      return Instantiate(GetProvider().nomoru);
    }

    public GameObject CreateMatoshi()
    {
      return Instantiate(GetProvider().matoshi);
    }

    public GameObject CreateYouto()
    {
      return Instantiate(GetProvider().youto);
    }
  }
}