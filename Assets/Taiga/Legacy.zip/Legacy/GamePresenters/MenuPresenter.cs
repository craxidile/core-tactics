﻿using UnityEngine;
using UnityEngine.UI;

namespace Taiga.GamePresenters
{
  public class MenuPresenter : MonoBehaviour
  {
    public GameObject playerMenu;
    public GameObject inactiveMoveMenu;
    public GameObject activeMoveMenu;
    public GameObject inactiveAttackMenu;
    public GameObject activeAttackMenu;
    public GameObject inactiveSpecialMenu;
    public GameObject activeSpecialMenu;
    public GameObject inactiveWaitMenu;
    public GameObject activeWaitMenu;

    public GameObject walkMenu;
    public GameObject activeConfirmWalkingMenu;
    public GameObject inactiveConfirmWalkingMenu;
    public GameObject activeCancelWalkingMenu;
    public GameObject inactiveCancelWalkingMenu;
  }
}