﻿using Taiga.GameComponents;
using UnityEngine;

namespace Taiga.GamePresenters
{
  public class SoundPresenter : MonoBehaviour
  {
    public GameObject background;
    public GameObject click;
    public GameObject mouseOver;
    public GameObject punch;

    public void Play(SoundEffectType type)
    {
      GameObject gameObject;
      switch (type)
      {
        case SoundEffectType.Click:
          gameObject = click;
          break;
        case SoundEffectType.MouseOver:
          gameObject = mouseOver;
          break;
        case SoundEffectType.Punch:
          gameObject = punch;
          break;
        default:
          return;
      }

      gameObject.SetActive(true);
      var audioSource = gameObject.GetComponent<AudioSource>();
      audioSource.Play();
    }
  }
}