﻿using Taiga.GameProviders;
using UnityEngine;

namespace Taiga.GamePresenters
{
  public class CharacterPresenter : MonoBehaviour
  {
    public ScriptableObject characterProvider;

    public CharacterProvider GetProvider()
    {
      return characterProvider as CharacterProvider;
    }

    public GameObject CreateAji()
    {
      return Instantiate(GetProvider().aji);
    }

    public GameObject CreateNomoru()
    {
      return Instantiate(GetProvider().nomoru);
    }
  }
}