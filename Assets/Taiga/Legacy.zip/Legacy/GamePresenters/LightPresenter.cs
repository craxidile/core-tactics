﻿using Taiga.GameProviders;
using UnityEngine;
using UnityEngine.Experimental.GlobalIllumination;

namespace Taiga.GamePresenters
{
  public class LightPresenter : MonoBehaviour
  {
    public Light mainLight;
  }
}