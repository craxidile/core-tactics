﻿using Taiga.Core;
using UnityEngine;

namespace Taiga.GamePresenters
{
  public abstract class MonoProvider<T> : MonoBehaviour where T : ScriptableObject, IProvider
  {
    public T provider;
  }
}