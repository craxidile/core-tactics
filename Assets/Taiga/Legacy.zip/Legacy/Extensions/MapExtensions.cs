﻿using System;
using Taiga.Core;
using Taiga.GameProviders;
using Taiga.Tools;

namespace Taiga.Extensions
{
  public static class MapExtensions
  {
    public static int[,] CreateMapBlueprint(this Contexts contexts)
    {
      var game = contexts.game;
      var mapSettings = contexts.GetProvider<MapSettingsProvider>();
      var playerEntities = contexts.Players();
      var currentPlayerIndex = game.currentPlayer.index;
      return MapTools.Generate(mapSettings.width, mapSettings.height, playerEntities, currentPlayerIndex);
    }

    public static Tuple<int, int>[] FindAdjacentCells(this Contexts contexts)
    {
      var playerEntity = contexts.CurrentPlayer();
      var (column, row) = playerEntity.position;
      var origin = Tuple.Create(column, row);
      return MapTools.FindAdjacentCells(contexts.CreateMapBlueprint(), origin);
    }

    public static Tuple<int, int>[] FindAttackableCells(this Contexts contexts)
    {
      var playerEntity = contexts.CurrentPlayer();
      var (column, row) = playerEntity.position;
      var origin = Tuple.Create(column, row);
      return MapTools.FindPossibleAttackCells(contexts.CreateMapBlueprint(), origin);
    }

    public static Tuple<int, int>[] FindPlayerRotationCells(this Contexts contexts)
    {
      var playerEntity = contexts.CurrentPlayer();
      var (column, row) = playerEntity.position;
      var origin = Tuple.Create(column, row);
      return MapTools.FindPlayerRotationCells(contexts.CreateMapBlueprint(), origin);
    }

    public static Tuple<int, int>[] FindWalkableCells(this Contexts contexts, int cellCount)
    {
      var playerEntity = contexts.CurrentPlayer();
      var (column, row) = playerEntity.position;
      return MapTools.PopulateCells(contexts.CreateMapBlueprint(), column, row, cellCount);
    }
  }
}