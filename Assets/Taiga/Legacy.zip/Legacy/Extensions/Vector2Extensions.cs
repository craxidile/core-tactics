﻿using UnityEngine;

namespace Taiga.Extensions
{
  public static class Vector2Extensions
  {
    public static void Deconstruct(this Vector2 vec2, out float outX, out float outY)
    {
      outX = vec2.x;
      outY = vec2.y;
    }
  }
}