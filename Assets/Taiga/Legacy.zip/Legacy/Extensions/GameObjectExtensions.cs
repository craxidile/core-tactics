﻿using UnityEngine;

namespace Taiga.Extensions
{
  public static class GameObjectExtensions
  {
    public static void Deconstruct(this GameObject gameObject, out Transform outTransform)
    {
      outTransform = gameObject.transform;
    }
  }
}