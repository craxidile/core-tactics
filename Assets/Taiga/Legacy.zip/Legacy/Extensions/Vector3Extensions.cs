﻿using UnityEngine;
using Vector3 = UnityEngine.Vector3;

namespace Taiga.Extensions
{
  public static class Vector3Extensions
  {
    public static void Deconstruct(this Vector3 vec3, out float outX, out float outY, out float outZ)
    {
        outX = vec3.x;
        outY = vec3.y;
        outZ = vec3.z;
    }

    public static Vector2 ToVector2(this Vector3 vec3)
    {
      return new Vector2(vec3.x, vec3.z);
    }

    public static Vector3 Clone(this Vector3 vec3)
    {
      return new Vector3(vec3.x, vec3.y, vec3.z);
    }
  }
}