﻿using System.Runtime.CompilerServices;
using Taiga.GameComponents;

namespace Taiga.Extensions
{
  public static class PlayerExtensions
  {
    public static GameEntity CurrentPlayer(this Contexts contexts)
    {
      var game = contexts.game;
      if (!game.hasCurrentPlayer)
      {
        return null;
      }

      var index = game.currentPlayer.index;
      return game.GetEntityWithPlayer(index);
    }

    public static GameEntity[] Players(this Contexts contexts)
    {
      var game = contexts.game;
      return game.GetGroup(GameMatcher.AllOf(GameMatcher.Player)).GetEntities();
    }
  }

}
